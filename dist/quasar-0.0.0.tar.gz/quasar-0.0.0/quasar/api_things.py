# Server part

@app.route("/api/v2/find_ground_state_energy", methods=["POST"])
@requires_api_token
@as_json
# @as_protobuf_find_ground_state_energy
@submit_call
@add_api_version
def find_ground_state_energy():
    logging.info("find_ground_state_energy called")
    
    # get json from client
    data = request.data
    
    # parse json
    param_dict = params_pb2.params_vqe()
    param_dict.ParseFromString(data)
    params = protobuf_to_python_dict(param_dict)
    
    # run some algorithm
    async_result = find_ground_state_energy_task.delay(params)
    logging.debug("REGULAR RESULT", extra=dict(async_result=async_result))
    return async_result
    
    
    
    
    
    
# Client part
@print_api_mismatch
@print_errors
def solve_binary(
        key,
        Q,
        higher_order=False,
        solver="dwave_software",
        constraints_linear_A=[],
        constraints_linear_b=[],
        constraints_sat_max_runs=3100,
        constraints_hard=False,
        constraints_penalty_scaling_factor=1,
        host="https://platform.qcware.com",
        ):
    

    params = {
        "key": key,
        "Q": enumerated_Q,
        "higher_order": higher_order,
        "solver": solver,
        "constraints_linear_A": constraints_linear_A,
        "constraints_linear_b": constraints_linear_b,
        "constraints_sat_max_runs": constraints_sat_max_runs,
        "constraints_hard": constraints_hard,
        "constraints_penalty_scaling_factor": constraints_penalty_scaling_factor,
    }

    
    result = request.post(host + "/api/v2/solve_binary", params, "solve_binary")
    result = result.json()

    return result
    




    