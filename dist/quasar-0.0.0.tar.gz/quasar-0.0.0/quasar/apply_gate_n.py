    @staticmethod
    def apply_gate_n(
        wfn1,
        wfn2,
        U,
        qubits,
        ):

        N = (wfn1.shape[0]&-wfn1.shape[0]).bit_length()-1
        if any(_ >= N for _ in qubits): raise RuntimeError('qubits >= N')
        if len(set(qubits)) != len(qubits): raise RuntimeError('duplicate entry in qubits')
        if wfn1.shape != (2**N,): raise RuntimeError('wfn1 should be (%d,) shape, is %r shape' % (2**N, wfn1.shape))
        if wfn2.shape != (2**N,): raise RuntimeError('wfn2 should be (%d,) shape, is %r shape' % (2**N, wfn2.shape))
           
        # hangover
        qubits2 = tuple(sorted(qubits))
        hangovers = (2**qubits2[0],) + tuple(2**(qubits2[A+1]-qubits2[A]-1) for A in range(len(qubits2)-1)) + (2**(N-qubits2[-1]-1),)
        shape = []
        for hangover in hangovers[:-1]:
            shape.append(hangover)
            shape.append(2)
        shape.append(hangovers[-1])
        shape = tuple(shape)
        
        wfn1v = wfn1.view() 
        wfn2v = wfn2.view()
        wfn1v.shape = shape
        wfn2v.shape = shape
        
        # symbol stock 
        hangover_stock = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
        bra_stock = 'abcdefghijklm'
        ket_stock = 'nopqrstuvwxyz'
    
        M = len(qubits)
        if M > 13: raise RuntimeError('Technical limit: cannot run N > 13')
        
        # einsum form for ordering gate
        bra_str = bra_stock[:M]
        ket_str = ket_stock[:M]
        bra_str2 = ''.join([bra_str[qubits.index(_)] for _ in qubits2])
        ket_str2 = ''.join([ket_str[qubits.index(_)] for _ in qubits2])
        U_str = ket_stock[:M] + bra_stock[:M]
        
        # print('bra_str',bra_str)
        # print('ket_str',ket_str)
        # print('bra_str2',bra_str2)
        # print('ket_str2',ket_str2)
        
        shape_U = tuple(2 for _ in range(2*M))
        U.shape = shape_U
        # print('shape_U',shape_U)
        # print('U',U.shape)
        U2 = np.einsum('%s%s->%s%s' % (bra_str, ket_str, bra_str2, ket_str2), U)
        
        # einsum form for applying gate
        wfn1_str = ''
        wfn2_str = ''
        for A in range(M):
            wfn1_str += hangover_stock[A]
            wfn1_str += bra_stock[A]
            wfn2_str += hangover_stock[A]
            wfn2_str += ket_stock[A]
        wfn1_str += hangover_stock[M]
        wfn2_str += hangover_stock[M]
        
        print('wfn1_str',wfn1_str)
        print('wfn2_str',wfn2_str)
        print('U_str',U_str)
        
        np.einsum('%s,%s->%s' % (wfn1_str, U_str, wfn2_str), wfn1v, U2, out=wfn2v)
        wfn2v = np.reshape(wfn2v, (-1,))
        
        return wfn2v