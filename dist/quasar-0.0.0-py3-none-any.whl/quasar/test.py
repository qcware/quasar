from quasar import PauliJordanWigner


pauli = PauliJordanWigner.Composition()

# result = pauli.__getitem__(4)
# print(result)



pauli = PauliJordanWigner.Substitution1()
result = pauli.__getitem__((2,5))
# print(result)



pauli = PauliJordanWigner.Substitution2()
result = pauli.__getitem__((1,3,5,7))
print(result)
























